L=[0.1,0.2,0.3,0.4,0.5]
print(L)
sum=L[0]+L[1]+L[2]+L[3]+L[4]
print(sum)
average=sum/2
print(average)
