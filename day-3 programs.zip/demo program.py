L=[1,2,3,4]
for i in range(len(L)):
    print(L[i
