L=[1,2,4,6,7,8,9]
print(L)
for i in L:
   if i%2==0:
       print(i)
