numbers=[elements for elements in "lord is my sheperd"]
print(numbers)
